//  Config.h Simple config library for RFbee

//  Copyright (c) 2010 Hans Klunder <hans.klunder (at) bigfoot.com>
//  Author: Hans Klunder, based on the original Rfbee v1.0 firmware by Seeedstudio
//  Version: May 22, 2010
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA



#ifndef Config_h
#define Config_h 1

#include "WProgram.h"

// config layout
#define CONFIG_RFBEE_MARKER 0  // Marker
#define CONFIG_HW_VERSION   1  // Hardware version  
#define CONFIG_FW_VERSION   2  // Firmware version
#define CONFIG_DEST_ADDR    3  // Receiver address
#define CONFIG_MY_ADDR      4  // Sender address
#define CONFIG_ADDR_CHECK   5  // Address checking
#define CONFIG_TX_THRESHOLD 6  // Transmit threshold
#define CONFIG_DATARATE     7  // RF data rate
#define CONFIG_BDINDEX      8  // Index to baudrate
#define CONFIG_PAINDEX      9  // Index to PowerAmplifier
#define CONFIG_CONFIG_ID    10  // Selected CCx configuration

// marker
#define CONFIG_RFBEE_MARKER_VALUE 0xAB

class CONFIG
{
  public:
    CONFIG(void);
    void reset(void);
    byte get(byte);
    void set(byte,byte);
    int initialized();
};

extern CONFIG Config;

#endif
