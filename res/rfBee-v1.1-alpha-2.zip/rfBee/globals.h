

//return values 0: ok, -1: error, 1: nothing
#define OK 0
#define ERR -1 
#define NOTHING 1
